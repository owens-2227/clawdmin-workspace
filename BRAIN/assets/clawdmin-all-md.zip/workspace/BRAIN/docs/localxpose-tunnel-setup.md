# LocalXpose Tunnel Setup Guide

Expose a local dashboard (or any HTTP service) to the internet via a persistent tunnel that survives reboots.

---

## What This Does

Your dashboard runs on `localhost:3000` (or whatever port). LocalXpose creates a public URL like `your-name.loclx.io` that tunnels traffic to it. A macOS LaunchAgent keeps it running 24/7.

```
Internet → your-name.loclx.io → LocalXpose tunnel → localhost:3000
```

---

## Step 1: Install LocalXpose

```bash
# macOS (Homebrew)
brew install localxpose

# Or download directly
# https://localxpose.io/docs/installation
```

Verify:
```bash
loclx --version
```

## Step 2: Authenticate

Get your access token from https://localxpose.io/dashboard/access-tokens

```bash
loclx account login
# Paste your access token when prompted
```

Verify:
```bash
loclx account status
# Should show your email and account type
```

## Step 3: Reserve a Custom Domain (Optional, Pro Plan)

Go to https://localxpose.io/dashboard/reserved-domains and reserve a subdomain like `my-dashboard.loclx.io`.

Free plan gives you a random subdomain that changes each restart. Pro plan ($6/mo) lets you reserve a permanent one.

## Step 4: Test the Tunnel Manually

Make sure your local service is running first, then:

```bash
# Basic (random subdomain)
loclx tunnel http --to localhost:3000

# With reserved domain
loclx tunnel http --to localhost:3000 --reserved-domain my-dashboard.loclx.io
```

Visit the URL it prints — you should see your dashboard. `Ctrl+C` to stop.

## Step 5: Create a LaunchAgent (Auto-Start on Boot)

Create the plist file:

```bash
cat > ~/Library/LaunchAgents/com.loclx.tunnel.plist << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.loclx.tunnel</string>

    <key>ProgramArguments</key>
    <array>
        <string>/opt/homebrew/bin/loclx</string>
        <string>tunnel</string>
        <string>http</string>
        <string>--to</string>
        <string>localhost:3000</string>
        <string>--reserved-domain</string>
        <string>my-dashboard.loclx.io</string>
    </array>

    <key>EnvironmentVariables</key>
    <dict>
        <key>HOME</key>
        <string>/Users/YOUR_USERNAME</string>
        <key>PATH</key>
        <string>/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin</string>
    </dict>

    <!-- Start when the plist is loaded (login / boot) -->
    <key>RunAtLoad</key>
    <true/>

    <!-- Restart automatically if it crashes -->
    <key>KeepAlive</key>
    <true/>

    <!-- Wait 10 seconds before restarting after a crash -->
    <key>ThrottleInterval</key>
    <integer>10</integer>

    <!-- Log files -->
    <key>StandardOutPath</key>
    <string>/tmp/loclx-tunnel.log</string>
    <key>StandardErrorPath</key>
    <string>/tmp/loclx-tunnel.err</string>
</dict>
</plist>
EOF
```

**Customize these values:**
- `localhost:3000` → your dashboard's local port
- `my-dashboard.loclx.io` → your reserved domain (or remove the `--reserved-domain` lines for a random one)
- `/Users/YOUR_USERNAME` → your actual macOS username
- `/opt/homebrew/bin/loclx` → verify with `which loclx` (Intel Macs use `/usr/local/bin/loclx`)

## Step 6: Load and Start

```bash
# Load the agent (starts it immediately due to RunAtLoad)
launchctl load ~/Library/LaunchAgents/com.loclx.tunnel.plist

# Verify it's running
launchctl list | grep loclx

# Check logs
tail -f /tmp/loclx-tunnel.log
```

## Managing the Tunnel

```bash
# Stop the tunnel
launchctl unload ~/Library/LaunchAgents/com.loclx.tunnel.plist

# Restart (stop + start)
launchctl unload ~/Library/LaunchAgents/com.loclx.tunnel.plist
launchctl load ~/Library/LaunchAgents/com.loclx.tunnel.plist

# Check if it's running
launchctl list | grep loclx
# If PID column shows a number → running. "-" → not running.

# View logs
cat /tmp/loclx-tunnel.log
cat /tmp/loclx-tunnel.err
```

## How It Works

| Component | Role |
|-----------|------|
| **LocalXpose (`loclx`)** | CLI tool that opens a reverse tunnel from their servers to your machine |
| **LaunchAgent plist** | macOS config file that tells launchd to run the tunnel on login |
| **`RunAtLoad: true`** | Starts the tunnel immediately when the plist is loaded (including on login/boot) |
| **`KeepAlive: true`** | If the process dies (crash, network blip), launchd restarts it automatically |
| **`ThrottleInterval: 10`** | Waits 10 seconds between restart attempts (prevents rapid crash loops) |
| **Reserved domain** | Permanent URL that doesn't change between restarts (Pro plan) |

The tunnel stays up as long as the machine is on and logged in. If the network drops, `KeepAlive` restarts it and it reconnects.

## Troubleshooting

**Tunnel not starting:**
```bash
# Check if loclx path is correct
which loclx

# Check if logged in
loclx account status

# Check error log
cat /tmp/loclx-tunnel.err
```

**Port conflict (another tunnel on same domain):**
Make sure you don't have two plists running the same tunnel (like we had). Check:
```bash
launchctl list | grep loclx
# If you see multiple entries, unload the duplicate
```

**Dashboard not accessible:**
1. Verify your local service is actually running: `curl localhost:3000`
2. Verify the tunnel is up: `launchctl list | grep loclx` (should show a PID)
3. Check the tunnel logs for errors

## Linux Alternative

On Linux, use a systemd service instead of a LaunchAgent:

```bash
sudo cat > /etc/systemd/system/loclx-tunnel.service << 'EOF'
[Unit]
Description=LocalXpose Tunnel
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=/usr/local/bin/loclx tunnel http --to localhost:3000 --reserved-domain my-dashboard.loclx.io
Restart=always
RestartSec=10
User=YOUR_USERNAME
Environment=HOME=/home/YOUR_USERNAME

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable loclx-tunnel
sudo systemctl start loclx-tunnel
sudo systemctl status loclx-tunnel
```
