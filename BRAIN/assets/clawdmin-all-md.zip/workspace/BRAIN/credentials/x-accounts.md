# X/Twitter Accounts

Format: `username:password:email:email_password:2fa_secret:auth_token:ct0`

## Account Mapping

| # | AdsPower Profile | AdsPower ID | X Handle | Proxy |
|---|-----------------|-------------|----------|-------|
| 73 | x-user1-alex-t | k1bpauax | eaceves72 | 158.106.212.94 |
| 74 | x-user2-sarah-m | k1bpaubl | 1ambitiousqirl | 172.56.44.80 |
| 75 | x-user3-james-r | k1bpauc0 | DeannaSaltLife | 97.237.93.204 |
| 76 | x-user4-lisa-k | k1bpaucd | Hephzilily | 71.125.40.160 |
| 77 | x-user5-mike-d | k1bpaucq | EricDanielAkpa | 153.67.51.151 |

## Full Credentials

### 1. eaceves72 (x-user1-alex-t)
- **Password:** kOD5m38IE
- **Email:** swansonkaelyn2858@hotmail.com
- **Email Password:** AJNMJQing3523
- **2FA Secret:** EL4YKDYMWGOG2JQR
- **Auth Token:** caf031cfb02bbaa995162249a26c79ac03497fa117b4d39179f141c526ff3434ea385da19102320c0dfc861519813e02fa9d6d8208be7239493941ae8ec9bf676f45d3d61d318a601d2ff4ba3d7ba39a
- **ct0:** 1570574e9a0ed968cfaa8c4814ffad2ccda424d9

### 2. 1ambitiousqirl (x-user2-sarah-m)
- **Password:** BkGOU1u2J
- **Email:** jaycewrightolgg@outlook.com
- **Email Password:** yy8Umkf6hR
- **2FA Secret:** IG7WF25VXK6T2PXS
- **Auth Token:** b83dea27fc30bbda12943098f1ca52eae1129e7402841ac2652a4382beddd50a5e74a1b29eba2ce2c6abc0c1640720306365dc2818b5b12ade19b7e829a935d7de60f72c8aeef84feb02a2e709a98e37
- **ct0:** 88fc092d9434fa6f345c93f0957cfb571444f673

### 3. DeannaSaltLife (x-user3-james-r)
- **Password:** Nt46gR28D
- **Email:** overtonharley996@hotmail.com
- **Email Password:** FPBNURkbh5929
- **2FA Secret:** YEUPQBQ3HTKWAQVQ
- **Auth Token:** 81c87ff8446bb6bcb3f337716b4ba2b5fbb70f65b169fb295ef9d7c0eaeb9d1fe942000e9e9eb0f662d92e3d74131950b8ea61b94aa98f604fc53fad78d4ba285b96e81c2f7dbb51675ec1228935b30e
- **ct0:** 2eeb372f36a328af79046977ce5afec467aed257

### 4. Hephzilily (x-user4-lisa-k)
- **Password:** H6cZORUtr
- **Email:** thiagoperryergl@outlook.com
- **Email Password:** xGaaeY0rJQ
- **2FA Secret:** ZYJKE7ZZRJ2HJNZY
- **Auth Token:** 0c1d2f8615b9bd9a54a42c83a860eb3c4e666992404985f3eb8a22bb0e4b8e7f2dd3b922c04b124577a5c410023ad5a4ab190e57e5c7ed9d809f01b56f256e39f09106d20027bef90d094f87ffce9eb0
- **ct0:** 1a7e159ed9fc5a04cfcb21838c8c839a3562e60d

### 5. EricDanielAkpa (x-user5-mike-d)
- **Password:** Va7MFbxzH
- **Email:** magnusandersencppb@outlook.com
- **Email Password:** OemDAUWLrA
- **2FA Secret:** FV4HJDARAGCPD5FB
- **Auth Token:** 45c6d2049a23eefc39d1a3c24da791fb55a1fff187b3dc8c2fd4aaccf031d1b081e0739079f60bf1949c341e848f4e0d6db4ef8b289019af6d2938001bcd36d93ca9fac8e2e983d44599ebd596895a42
- **ct0:** a15e9730db7a9c27d5f9d889ae5749df53a7d0d7
