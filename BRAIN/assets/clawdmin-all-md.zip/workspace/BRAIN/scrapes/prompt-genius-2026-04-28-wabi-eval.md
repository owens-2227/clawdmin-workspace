# Wabi Viability Eval — ChatGPT Prompt Genius Scrape 2026-04-28

## Wabi SDK Constraints Applied
- AI content client (text, structured, streaming, MCP) ✅
- KV store (MongoDB-backed, persistent) ✅
- WabiChat, TTS (ElevenLabs) ✅
- Push notifications, time/geofence/init triggers ✅
- Rich UI components ✅
- NO arbitrary HTTP requests, NO filesystem, NO background processes outside triggers
- ~10-15 module budget, Core bundle only (~285 modules)

---

## Viable Candidates

### 1. ADHD State-Based Prompt Retrieval System ⭐⭐⭐
- **Source:** "Your ADHD Brain Doesn't Need More Prompts..." (66↑, 21 comments)
- **Concept:** Prompt library organized by emotional state (overwhelmed, brain fog, low energy) instead of task category. 3-second access rule.
- **Wabi fit:** AI content for prompt suggestions + KV store for user's library + init/time triggers for check-ins + push notifications for state-based nudges. Perfect fit.
- **Link:** https://reddit.com/r/ChatGPTPromptGenius/comments/1srjift/

### 2. AI Journaling Companion ⭐⭐⭐
- **Source:** "Prompt Help" — user using ChatGPT as diary (10↑, 16 comments)
- **Concept:** Daily journaling app with AI reflection, follow-up questions, and emotional pattern tracking.
- **Wabi fit:** AI content for reflective prompts + KV store for entries + time triggers for daily reminders + push notifications. Strong fit.
- **Link:** https://reddit.com/r/ChatGPTPromptGenius/comments/1srrqlk/

### 3. Framework Generator ⭐⭐
- **Source:** "i stopped asking Claude for answers. i started asking for frameworks" (716↑, 33 comments)
- **Concept:** Input a problem → get a reusable decision framework (checklist, flowchart, evaluation criteria).
- **Wabi fit:** AI content client does the heavy lifting. KV store saves generated frameworks. Simple but high engagement potential.
- **Link:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sts5gv/

### 4. Tsundere AI Companion ⭐⭐
- **Source:** "Tsundere Chat GPT" (15↑, 12 comments)
- **Concept:** Persona-based AI chat with emotional dynamics (tsundere, supportive friend, etc.)
- **Wabi fit:** WabiChat + AI content + TTS for voice. Fun/viral potential. Niche but buildable.
- **Link:** https://reddit.com/r/ChatGPTPromptGenius/comments/1su920f/

### 5. Customer-Voice Copy Generator ⭐⭐
- **Source:** "i found a marketing prompt so good..." (13↑, 3 comments)
- **Concept:** Paste product description → get marketing copy written from customer perspective (testimonial style, objection-addressing, forwardable).
- **Wabi fit:** Pure AI content generation + KV for saved outputs. Straightforward build.
- **Link:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sxg6wo/

### 6. Pre-Mortem Project Planner ⭐⭐
- **Source:** "My prompt for doing a pre mortem on projects" (5↑, 1 comment)
- **Concept:** Input project details → get structured failure analysis with mitigation strategies.
- **Wabi fit:** AI content for analysis + KV for saved projects. Clean utility app.
- **Link:** https://reddit.com/r/ChatGPTPromptGenius/comments/1stx6gu/

### 7. Model Switch Advisor ⭐⭐
- **Source:** "The Model Hype Detector" (5↑, 3 comments)
- **Concept:** Describe your current AI workflow → get assessment of whether switching models is worth it.
- **Wabi fit:** AI content only. Very simple build. Timely given model churn.
- **Link:** https://reddit.com/r/ChatGPTPromptGenius/comments/1subq6t/

---

## Not Viable (18 posts)

Most scraped posts are prompting techniques, discussions, or meta content — not app concepts. Specific rejections:
- **SEO/Ads tools** (3 posts) — require external API access (Google Ads, web scraping)
- **Security audit tools** (2 posts) — need network/system access beyond Wabi SDK
- **Safety/routing research** (3 posts) — academic findings, not buildable products
- **Pure discussion/comparison** (4 posts) — "ChatGPT Pro vs Claude MAX", "best translation workflow", etc.
- **Image gen help requests** (2 posts) — user support questions, not app ideas
- **Token optimization tips** (2 posts) — "caveman prompts", "actually" trick — techniques, not apps
- **File processing needs** (2 posts) — math PDF condenser, fiction with manuscript context — need filesystem
