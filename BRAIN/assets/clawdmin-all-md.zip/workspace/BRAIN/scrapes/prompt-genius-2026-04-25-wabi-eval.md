# ChatGPT Prompt Genius → Wabi Mini App Evaluation
**Week of April 21–25, 2026** | Scraped 25 posts, 24 passed basic filter

## Wabi SDK Capabilities Reference
- AI content client (short/long text, structured entities, streaming, MCP)
- Gmail send/search, Google Calendar create/update
- Apple Health queries (steps, HR, sleep, workouts)
- Composio for third-party OAuth integrations
- Persistent MongoDB-backed KV store + Zustand persistence/streaming/multiplayer
- In-app chat, TTS (ElevenLabs), multiplayer/presence
- Time-based triggers, geofence triggers, init triggers
- Push notifications via LLM, content generation on schedule
- Rich UI components (buttons, typography, tabs, markdown, date pickers, etc.)
- CANNOT: arbitrary HTTP, device filesystem, background processes outside triggers, camera/contacts/native iOS without bridge, npm outside Core bundle (~285 modules), >10-15 module budget

---

## 🟢 Strong Wabi Mini App Candidates

### 1. "Dietitian Meal Prep Prompt" (47↑)
**App concept:** Conversational AI meal planner — runs an intake interview, then generates personalized weekly meal plans with grocery lists and prep sequences. Integrates Apple Health for nutritional context, Calendar for meal prep scheduling, KV store for preference history.
**Wabi fit:** ⭐⭐⭐⭐⭐ — AI content client for conversational plan generation, Apple Health for activity/nutrition data, Calendar for reminders, KV store for preference history. All native Wabi capabilities. Repeat winner.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sq6inr/

### 2. "Weekly Plan Reality Check" (34↑)
**App concept:** Paste your week plan, AI identifies what you'll actually skip and why. Integrates Google Calendar for real schedule data, persistent tracking of prediction accuracy over time. Monday morning push notifications.
**Wabi fit:** ⭐⭐⭐⭐⭐ — Calendar API + AI content client + KV persistence. Time-based triggers for Monday check-ins. Push notifications. Sticky habit loop. Repeat winner.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sp9irf/

### 3. "ADHD State-Based Prompt Retrieval" (63↑)
**App concept:** Organize AI prompts/tools by emotional/energy state instead of topic. "Overwhelmed" folder, "Brain Fog" folder. 3-second access to emergency prompts. Context-anchored templates with ADHD-specific triggers.
**Wabi fit:** ⭐⭐⭐⭐ — KV store for prompt library organized by state, AI content client to adapt prompts to current context, push notifications for check-ins, simple UI with large tap targets. Geofence triggers could add location awareness. Strong emotional hook.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1srjift/

### 4. "SEO Research Engine" (27↑)
**App concept:** Paste a service/audience/market, get structured SEO dataset: query expansion, intent mapping, entity extraction, competitor gaps, buyer psychology. Save and compare across projects.
**Wabi fit:** ⭐⭐⭐⭐ — AI structured entity generation for the research dataset, KV store for project history. No external HTTP needed since AI does the analysis. Useful for solopreneurs.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1ssbbmi/

### 5. "Research Credibility Checker" (10↑)
**App concept:** Paste a research paper/article, get structured credibility assessment: methodology check, citation verification, AI-generation signals, bias flags. Score card output.
**Wabi fit:** ⭐⭐⭐⭐ — AI structured entities for scoring rubric, KV store for analyzed papers. Works on pasted text only (no web fetching needed). Clean utility.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sqm5jp/

### 6. "Recommendation Poisoning Detector" (7↑)
**App concept:** Paste an AI-generated recommendation, detect manipulation signals: product placement, ad-copy language, source laundering, brand concentration. Consumer protection tool.
**Wabi fit:** ⭐⭐⭐⭐ — AI content client for analysis, structured entities for signal scoring. KV store for tracking patterns. Novel concept.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1srkbzj/

## 🟡 Possible But Thin

- **"AI Diary/Journaling Companion"** (12↑) — Custom instructions for therapeutic journaling. AI + KV for history + push for check-ins. Works but the post is a help request, not a fleshed-out concept.
- **"AI Security Audit Partner"** (7↑) — Security posture analysis. AI analysis works but very niche audience and needs pasted configs.
- **"Prompt Organizer Framework"** (4↑) — Organize prompts by project, type, tested status. KV + UI. Generic, could be a feature not an app.

## 🔴 Not Viable as Wabi Apps

| Post | Score | Reason |
|------|-------|--------|
| "Frameworks not answers" | 458 | Prompting philosophy article, not an app concept |
| "Caveman theory" token savings | 345 | Prompting tip, not an app |
| "AI reading list" | 92 | Curated links list, not an app |
| "Goal section fixes outputs" | 58 | Prompting tip, not an app |
| "What NOT to do" prompting | 32 | Prompting advice, not an app |
| "Fiction writing context" | 32 | Writing workflow tip, not an app |
| "AI safety refusal patterns" | 20 | Research methodology post, not an app |
| "Tsundere Chat GPT" | 13 | Persona prompt, not a standalone app |
| "Better prompt structure" | 13 | Generic observation, not an app |
| "ChatGPT Pro vs Claude MAX" | 12 | Discussion/comparison, not an app |
| "Negative constraints research" | 6 | Technique research, not an app |
| "Fixed ChatGPT acting dumb" | 6 | Prompt rewriter pitch, not an app |
| "LLM context reduction" | 6 | Dev library/technique, needs filesystem access |
| "SEO prompts question" | 5 | Question post, not an app |
| "Claude Projects loading" | 3 | Technical discussion, not an app |

**Count: 15 not viable** — Mostly prompting tips, technique articles, and discussion posts.

---

## 📊 Summary

| Category | Count |
|----------|-------|
| Strong Wabi candidates | 6 |
| Possible but thin | 3 |
| Not viable | 15 |
| Rejected by filter | 1 |
| **Total scraped** | **25** |

**Top 3 recommendations for immediate prototyping:**
1. **ADHD State-Based Retrieval** (63↑) — Highest score among viable candidates, strong emotional hook, simple UX, growing ADHD+AI crossover audience.
2. **Meal Prep AI** (47↑) — High utility, conversational intake flow, Apple Health + Calendar + AI generation. Repeat winner.
3. **Weekly Plan Reality Check** (34↑) — Calendar integration, habit loop, push notifications for Monday check-ins. Repeat winner.
