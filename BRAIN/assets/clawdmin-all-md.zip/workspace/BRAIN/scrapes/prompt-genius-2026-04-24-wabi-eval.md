# ChatGPT Prompt Genius → Wabi Mini App Evaluation
**Week of April 21–24, 2026** | Scraped 25 posts, 24 passed basic filter

## Wabi SDK Capabilities Reference
- AI content client (short/long text, structured entities, streaming, MCP)
- Gmail send/search, Google Calendar create/update
- Apple Health queries (steps, HR, sleep, workouts)
- Composio for third-party OAuth integrations
- Persistent MongoDB-backed KV store + Zustand persistence/streaming/multiplayer
- In-app chat, TTS (ElevenLabs), multiplayer/presence
- Time-based triggers, geofence triggers, init triggers
- Push notifications via LLM, content generation on schedule
- Rich UI components (buttons, typography, tabs, markdown, date pickers, etc.)
- CANNOT: arbitrary HTTP, device filesystem, background processes outside triggers, camera/contacts/native iOS without bridge, npm outside Core bundle (~285 modules), >10-15 module budget

---

## 🟢 Strong Wabi Mini App Candidates

### 1. "Dietitian Meal Prep Prompt" (50↑)
**App concept:** Conversational AI meal planner — runs an intake interview, then generates personalized weekly meal plans with grocery lists and prep sequences. Integrates Apple Health for nutritional context, Calendar for meal prep scheduling, KV store for history.
**Wabi fit:** ⭐⭐⭐⭐⭐ — AI content client for conversational plan generation, Apple Health for activity/nutrition data, Calendar for reminders, KV store for preference history. All native Wabi capabilities.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sq6inr/

### 2. "Weekly Plan Reality Check" (35↑)
**App concept:** Paste your week plan, AI identifies what you'll actually skip and why. Integrates Google Calendar for real schedule data, persistent tracking of prediction accuracy over time. Monday morning push notifications.
**Wabi fit:** ⭐⭐⭐⭐⭐ — Calendar API + AI content client + KV persistence. Time-based triggers for Monday check-ins. Push notifications. Sticky habit loop.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sp9irf/

### 3. "Legal Doc → Plain English" (25↑)
**App concept:** Paste legal text, get plain-English breakdown with key obligations, deadlines, and red flags highlighted. Save analyzed docs for reference.
**Wabi fit:** ⭐⭐⭐⭐⭐ — AI long text + structured entities for obligation extraction. KV store for document library. Simple UI, high utility, clear use case.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1soft6v/

### 4. "ADHD State-Based Prompt Retrieval" (61↑)
**App concept:** Organize AI prompts by emotional/energy state instead of topic. "Overwhelmed" folder instead of "Email" folder. 3-second access to emergency prompts. Context-anchored templates with ADHD-specific triggers.
**Wabi fit:** ⭐⭐⭐⭐ — KV store for prompt library organized by state, AI content client to adapt prompts to current context, push notifications for check-ins, simple UI with large tap targets. Geofence triggers could add location awareness.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1srjift/

### 5. "SEO Research Engine" (30↑)
**App concept:** Paste a service/audience/market, get structured SEO dataset: query expansion, intent mapping, entity extraction, competitor gaps, buyer psychology. Save and compare across projects.
**Wabi fit:** ⭐⭐⭐⭐ — AI structured entity generation for the research dataset, KV store for project history. No external HTTP needed since AI does the analysis. Useful for solopreneurs.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1ssbbmi/

### 6. "Research Credibility Checker" (9↑)
**App concept:** Paste a research paper/article, get structured credibility assessment: methodology check, citation verification, AI-generation signals, bias flags. Score card output.
**Wabi fit:** ⭐⭐⭐⭐ — AI structured entities for scoring rubric, KV store for analyzed papers. Works on pasted text only (no web fetching needed). Clean utility.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sqm5jp/

### 7. "Recommendation Poisoning Detector" (8↑)
**App concept:** Paste an AI-generated recommendation, detect manipulation signals: product placement, ad-copy language, source laundering, brand concentration. Consumer protection tool.
**Wabi fit:** ⭐⭐⭐⭐ — AI content client for analysis, structured entities for signal scoring. KV store for tracking patterns over time. Novel concept.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1srkbzj/

## 🟡 Possible But Thin

- **"Prompt Organizer/Library"** (6↑) — Framework for organizing prompts by project, type, tested status. KV store + UI. Works but generic. Could be a feature, not an app.
- **"AI Security Audit Partner"** (8↑) — Security posture analysis tool. Needs pasted configs/architecture. AI analysis works but niche audience and potentially needs external verification.
- **"Prompt Generator"** (6↑) — Turn vague prompts into specific ones. Pure AI text transformation. Too thin for standalone app.

## 🔴 Not Viable as Wabi Apps

| Post | Score | Reason |
|------|-------|--------|
| "Caveman theory" token savings | 295 | Prompting technique/article, not an app concept |
| "Frameworks not answers" | 289 | Prompting philosophy, not an app |
| "AI reading list" | 94 | Curated links list, not an app |
| "Goal section fixes outputs" | 57 | Prompting tip, not an app |
| "What NOT to do" prompting | 31 | Prompting advice, not an app |
| "Fiction writing context" | 29 | Writing workflow tip, not an app |
| "AI safety refusal patterns" | 19 | Research methodology post, not an app |
| "ChatGPT Pro vs Claude MAX" | 13 | Discussion/comparison, not an app |
| "Better prompt structure" | 11 | Generic observation, not an app |
| "Tsundere Chat GPT" | 12 | Persona prompt, not a standalone app |
| "Prompt Help (diary)" | 12 | Help request, not an app |
| "Fixed ChatGPT acting dumb" | 4 | Prompt rewriter pitch, not an app |
| "SEO prompts question" | 3 | Question post, not an app |
| "Translation workflow" | 4 | Workflow discussion, not an app |
| "Reducing LLM context" | 7 | Dev technique/library, not consumer app |

**Count: 15 not viable** — Almost all are prompting tips, technique articles, or discussion posts with no app-shaped problem to solve.

---

## 📊 Summary

| Category | Count |
|----------|-------|
| Strong Wabi candidates | 7 |
| Possible but thin | 3 |
| Not viable (tips/articles/discussions) | 15 |
| **Total scraped** | **25** |

**Top 3 recommendations for immediate prototyping:**
1. **Meal Prep AI** (50↑) — Highest utility, conversational intake flow, uses Apple Health + Calendar + AI generation. Repeat winner from last week.
2. **ADHD State-Based Retrieval** (61↑) — Highest score among viable candidates, strong emotional hook, simple UX, growing ADHD+AI crossover audience.
3. **Legal → Plain English** (25↑) — High value, simple UX, clear use case, repeat winner from last week.
