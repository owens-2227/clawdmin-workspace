# ChatGPT Prompt Genius → Wabi Mini App Evaluation
**Week of April 21–27, 2026** | Scraped 25 posts, 24 passed basic filter

## Wabi SDK Capabilities Reference
- AI content client (short/long text, structured entities, streaming, MCP)
- Gmail send/search, Google Calendar create/update
- Apple Health queries (steps, HR, sleep, workouts)
- Composio for third-party OAuth integrations
- Persistent MongoDB-backed KV store + Zustand persistence/streaming/multiplayer
- In-app chat, TTS (ElevenLabs), multiplayer/presence
- Time-based triggers, geofence triggers, init triggers
- Push notifications via LLM, content generation on schedule
- Rich UI components (buttons, typography, tabs, markdown, date pickers, etc.)
- CANNOT: arbitrary HTTP, device filesystem, background processes outside triggers, camera/contacts/native iOS without bridge, npm outside Core bundle (~285 modules), >10-15 module budget

---

## 🟢 Strong Wabi Mini App Candidates

### 1. "ADHD State-Based Prompt Retrieval" (67↑)
**App concept:** Organize AI prompts/tools by emotional/energy state instead of topic. "Overwhelmed" folder, "Brain Fog" folder. 3-second access to emergency prompts. Context-anchored templates with ADHD-specific triggers.
**Wabi fit:** ⭐⭐⭐⭐⭐ — KV store for prompt library organized by state, AI content client to adapt prompts to current context, push notifications for check-ins, simple UI with large tap targets. Geofence triggers could add location awareness. Strong emotional hook. Repeat winner from last week.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1srjift/

### 2. "Goal-Oriented Prompt Builder" (61↑)
**App concept:** Guided prompt builder that forces users to define Task, Context, Goal, Tone, and Rules before generating. Saves tested templates. AI evaluates prompt quality and suggests improvements.
**Wabi fit:** ⭐⭐⭐⭐⭐ — AI content client for prompt evaluation/improvement, KV store for template library, simple form UI components (text inputs, tabs). Very clean utility, low complexity.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sr62t0/

### 3. "SEO Research Engine" (27↑)
**App concept:** Paste a service/audience/market, get structured SEO dataset: query expansion, intent mapping, entity extraction, competitor gaps, buyer psychology. Save and compare across projects.
**Wabi fit:** ⭐⭐⭐⭐ — AI structured entity generation for the research dataset, KV store for project history. No external HTTP needed since AI does the analysis. Useful for solopreneurs. Repeat winner.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1ssbbmi/

### 4. "Research Credibility Checker" (11↑)
**App concept:** Paste a research paper/article, get structured credibility assessment: methodology check, citation verification, AI-generation signals, bias flags. Score card output.
**Wabi fit:** ⭐⭐⭐⭐ — AI structured entities for scoring rubric, KV store for analyzed papers. Works on pasted text only (no web fetching needed). Clean utility. Repeat winner.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sqm5jp/

### 5. "Recommendation Poisoning Detector" (8↑)
**App concept:** Paste an AI-generated recommendation, detect manipulation signals: product placement, ad-copy language, source laundering, brand concentration. Consumer protection tool.
**Wabi fit:** ⭐⭐⭐⭐ — AI content client for analysis, structured entities for signal scoring. KV store for tracking patterns. Novel concept. Repeat winner.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1srkbzj/

### 6. "Model Hype Detector" (4↑)
**App concept:** Evaluate whether switching AI models actually matters for your use case. Paste your current setup and the new model, get a pragmatic assessment: real vs perceived gains, switching cost, production impact score.
**Wabi fit:** ⭐⭐⭐⭐ — AI content client for analysis, structured entities for scoring. KV store for comparison history. Low score but novel concept.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1subq6t/

### 7. "Google Ads Search Term Analyzer" (3↑)
**App concept:** Paste Google Ads search term data, get intent classification, conversion probability estimates, keep/test/negative recommendations, and top keywords to focus on.
**Wabi fit:** ⭐⭐⭐⭐ — AI structured entities for analysis table, KV store for campaign history. Works on pasted data. Niche but high-value for advertisers.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sv2zna/

## 🟡 Possible But Thin

- **"AI Diary/Journaling Companion"** (12↑) — Custom instructions for therapeutic journaling. AI + KV for history + push for check-ins. Works but the post is a help request, not a fleshed-out concept.
  **URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1srrqlk/
- **"AI Security Audit Partner"** (8↑) — Security posture analysis. AI analysis works but very niche audience and needs pasted configs.
  **URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sshwue/

## 🔴 Not Viable as Wabi Apps

| Post | Score | Reason |
|------|-------|--------|
| "Frameworks not answers" | 703 | Prompting philosophy article, not an app concept |
| "Caveman theory" token savings | 395 | Prompting tip/technique, not an app |
| "AI reading list" | 97 | Curated links list, not an app |
| "Negative constraints research" | 11 | Technique research, not an app |
| "Fiction writing context" | 27 | Writing workflow tip, not an app |
| "AI safety refusal patterns" | 26 | Research methodology post, not an app |
| "Routing architecture research" | 3 | Technique research, not an app |
| "Tsundere Chat GPT" | 14 | Persona prompt, not a standalone app |
| "Better prompt structure" | 13 | Generic observation, not an app |
| "ChatGPT Pro vs Claude MAX" | 13 | Discussion/comparison, not an app |
| "The word 'actually'" | 20 | Prompting tip, not an app |
| "SEO prompts question" | 5 | Question post, not an app |
| "Claude Projects loading" | 6 | Technical discussion, not an app |
| "Help with image generation" | 4 | Help request, not an app |
| "Math lecture notes condenser" | 5 | Task-specific request, needs file upload |
| "Prompt organizer framework" | 5 | Commercial plug for existing desktop app |

**Count: 16 not viable** — Mostly prompting tips, technique articles, and discussion posts.

---

## 📊 Summary

| Category | Count |
|----------|-------|
| Strong Wabi candidates | 7 |
| Possible but thin | 2 |
| Not viable | 16 |
| Rejected by filter | 1 |
| **Total scraped** | **25** |

**Top 3 recommendations for immediate prototyping:**
1. **ADHD State-Based Retrieval** (67↑) — Highest score among viable candidates, strong emotional hook, simple UX, growing ADHD+AI crossover audience. Repeat winner.
2. **Goal-Oriented Prompt Builder** (61↑) — High engagement, simple form-based UX, prompt quality evaluation loop. New strong entry.
3. **SEO Research Engine** (27↑) — Solopreneur tool, structured AI output, project comparison. Repeat winner.
