# ChatGPT Prompt Genius → Wabi Mini App Evaluation
**Week of April 21–26, 2026** | Scraped 25 posts, 24 passed basic filter

## Wabi SDK Capabilities Reference
- AI content client (short/long text, structured entities, streaming, MCP)
- Gmail send/search, Google Calendar create/update
- Apple Health queries (steps, HR, sleep, workouts)
- Composio for third-party OAuth integrations
- Persistent MongoDB-backed KV store + Zustand persistence/streaming/multiplayer
- In-app chat, TTS (ElevenLabs), multiplayer/presence
- Time-based triggers, geofence triggers, init triggers
- Push notifications via LLM, content generation on schedule
- Rich UI components (buttons, typography, tabs, markdown, date pickers, etc.)
- CANNOT: arbitrary HTTP, device filesystem, background processes outside triggers, camera/contacts/native iOS without bridge, npm outside Core bundle (~285 modules), >10-15 module budget

---

## 🟢 Strong Wabi Mini App Candidates

### 1. "Dietitian Meal Prep Prompt" (49↑)
**App concept:** Conversational AI meal planner — runs an intake interview, then generates personalized weekly meal plans with grocery lists and prep sequences. Integrates Apple Health for nutritional context, Calendar for meal prep scheduling, KV store for preference history.
**Wabi fit:** ⭐⭐⭐⭐⭐ — AI content client for conversational plan generation, Apple Health for activity/nutrition data, Calendar for reminders, KV store for preference history. All native Wabi capabilities. Repeat winner.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sq6inr/

### 2. "ADHD State-Based Prompt Retrieval" (68↑)
**App concept:** Organize AI prompts/tools by emotional/energy state instead of topic. "Overwhelmed" folder, "Brain Fog" folder. 3-second access to emergency prompts. Context-anchored templates with ADHD-specific triggers.
**Wabi fit:** ⭐⭐⭐⭐ — KV store for prompt library organized by state, AI content client to adapt prompts to current context, push notifications for check-ins, simple UI with large tap targets. Geofence triggers could add location awareness. Strong emotional hook. Repeat winner.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1srjift/

### 3. "SEO Research Engine" (30↑)
**App concept:** Paste a service/audience/market, get structured SEO dataset: query expansion, intent mapping, entity extraction, competitor gaps, buyer psychology. Save and compare across projects.
**Wabi fit:** ⭐⭐⭐⭐ — AI structured entity generation for the research dataset, KV store for project history. No external HTTP needed since AI does the analysis. Useful for solopreneurs.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1ssbbmi/

### 4. "Research Credibility Checker" (11↑)
**App concept:** Paste a research paper/article, get structured credibility assessment: methodology check, citation verification, AI-generation signals, bias flags. Score card output.
**Wabi fit:** ⭐⭐⭐⭐ — AI structured entities for scoring rubric, KV store for analyzed papers. Works on pasted text only (no web fetching needed). Clean utility.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sqm5jp/

### 5. "Recommendation Poisoning Detector" (8↑)
**App concept:** Paste an AI-generated recommendation, detect manipulation signals: product placement, ad-copy language, source laundering, brand concentration. Consumer protection tool.
**Wabi fit:** ⭐⭐⭐⭐ — AI content client for analysis, structured entities for signal scoring. KV store for tracking patterns. Novel concept.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1srkbzj/

### 6. "Goal-Oriented Prompt Builder" (58↑)
**App concept:** Guided prompt builder that forces users to define Task, Context, Goal, Tone, and Rules before generating. Saves tested templates. AI evaluates prompt quality.
**Wabi fit:** ⭐⭐⭐⭐ — AI content client for prompt evaluation/improvement, KV store for template library, simple form UI. Good utility tool.
**URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sr62t0/

## 🟡 Possible But Thin

- **"AI Diary/Journaling Companion"** (11↑) — Custom instructions for therapeutic journaling. AI + KV for history + push for check-ins. Works but the post is a help request, not a fleshed-out concept.
  **URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1srrqlk/
- **"AI Security Audit Partner"** (6↑) — Security posture analysis. AI analysis works but very niche audience and needs pasted configs.
  **URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sshwue/
- **"Prompt Organizer Framework"** (5↑) — Organize prompts by project, type, tested status. KV + UI. Generic, could be a feature not an app.
  **URL:** https://reddit.com/r/ChatGPTPromptGenius/comments/1sr8dl6/

## 🔴 Not Viable as Wabi Apps

| Post | Score | Reason |
|------|-------|--------|
| "Frameworks not answers" | 643 | Prompting philosophy article, not an app concept |
| "Caveman theory" token savings | 370 | Prompting tip, not an app |
| "AI reading list" | 96 | Curated links list, not an app |
| "What NOT to do" prompting | 15 | Prompting advice/research, not an app |
| "Fiction writing context" | 30 | Writing workflow tip, not an app |
| "AI safety refusal patterns" | 23 | Research methodology post, not an app |
| "Tsundere Chat GPT" | 14 | Persona prompt, not a standalone app |
| "Better prompt structure" | 13 | Generic observation, not an app |
| "ChatGPT Pro vs Claude MAX" | 15 | Discussion/comparison, not an app |
| "Negative constraints research" | 11 | Technique research, not an app |
| "Fixed ChatGPT acting dumb" | 5 | Prompt rewriter pitch, not an app |
| "LLM context reduction" | 6 | Dev library/technique, needs filesystem access |
| "SEO prompts question" | 6 | Question post, not an app |
| "Claude Projects loading" | 7 | Technical discussion, not an app |
| "Math lecture notes condenser" | 4 | Task-specific request, needs file upload |

**Count: 15 not viable** — Mostly prompting tips, technique articles, and discussion posts.

---

## 📊 Summary

| Category | Count |
|----------|-------|
| Strong Wabi candidates | 6 |
| Possible but thin | 3 |
| Not viable | 15 |
| Rejected by filter | 1 |
| **Total scraped** | **25** |

**Top 3 recommendations for immediate prototyping:**
1. **ADHD State-Based Retrieval** (68↑) — Highest score among viable candidates, strong emotional hook, simple UX, growing ADHD+AI crossover audience. Repeat winner.
2. **Meal Prep AI** (49↑) — High utility, conversational intake flow, Apple Health + Calendar + AI generation. Repeat winner.
3. **Goal-Oriented Prompt Builder** (58↑) — New entry, high engagement, simple form-based UX, prompt quality evaluation loop.
