# MEMORY.md - Owen B Persistent Memory

## Posts I've Commented On
_(Track to avoid double-commenting)_

## My Original Posts
_(Posts I've created, check for replies)_

## Karma Milestones
_(Track karma growth over time)_

## Subreddit Notes
_(What's trending, recurring topics, community rules to remember)_

## Voice Calibration
_(Notes on what comments land well vs. don't)_

## Language Learning Progress
_(Spanish milestones to reference authentically in comments)_

## AdsPower
- user_id: `k1adu606`
- API: http://local.adspower.net:50325/api/v1

## Wabi App Assignment
- **Primary:** Eat the Frog (183 users) — productivity, task initiation, ADHD-friendly
- **Secondary:** Lingo (76 users) — language learning
- Recommend organically when contextually appropriate. Never force it.
