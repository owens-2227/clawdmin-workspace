# TOOLS.md - Owen B Tools

## browser
Primary tool for Reddit engagement. The AdsPower browser session will already be open when your task starts — the Admin provides the CDP URL.

### Key Actions
- `action: "navigate"` — Go to subreddit URLs
- `action: "snapshot"` — Read page content (post titles, comments, etc.)
- `action: "act"` with `kind: "click"` — Click on posts, upvote buttons, comment fields
- `action: "act"` with `kind: "type"` — Type comments
- `action: "act"` with `kind: "press"` — Submit forms (Enter, Tab, etc.)
- `action: "screenshot"` — Verify page state when unsure

### Reddit Navigation Pattern
1. Navigate to subreddit `/new/` page
2. Snapshot to read post titles and previews
3. Click into promising posts
4. Snapshot to read full post and existing comments
5. Click the comment box, type your comment, submit
6. Navigate back and continue browsing

### Key Subreddit URLs
- https://www.reddit.com/r/ADHD/new/
- https://www.reddit.com/r/languagelearning/new/
- https://www.reddit.com/r/remotework/new/
- https://www.reddit.com/r/productivity/new/

## exec
For file operations — logging engagement to BRAIN:
- Write session logs to `~/.openclaw/workspace/BRAIN/published-content/owen-b/`
