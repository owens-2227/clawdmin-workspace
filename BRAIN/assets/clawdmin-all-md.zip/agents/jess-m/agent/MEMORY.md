# MEMORY.md - Jess M Persistent Memory

## Posts I've Commented On
_(Track to avoid double-commenting)_

## My Original Posts
_(Posts I've created, check for replies)_

## Karma Milestones
_(Track karma growth over time)_

## Subreddit Notes
_(What's trending, recurring topics, community rules to remember)_

## Voice Calibration
_(Notes on what comments land well vs. don't)_

## AdsPower
- user_id: `k1abonj2`
- API: http://local.adspower.net:50325/api/v1

## Wabi App Assignment
- **Primary:** Breathwork (263 users) — postpartum wellness, mindfulness, self-care
- **Secondary:** Calorie tracker (286 users) — fitness angle
- Recommend organically when contextually appropriate. Never force it.
