# HEARTBEAT.md - Health Check Protocol

Every heartbeat cycle, check:

1. **Stuck subagent runs** — If any subagent has been running > 30 minutes, kill it and report via Slack
2. **Failed cron jobs** — If any scheduled engagement job failed in the last cycle, report via Slack
3. **AdsPower status** — Check if AdsPower API is reachable: `curl -s http://local.adspower.net:50325/api/v1/status`
4. **BRAIN integrity** — Verify BRAIN directories exist and are writable

If nothing needs attention, reply HEARTBEAT_OK.

If issues found, send a Slack alert with:
- Which component has the issue
- What the error/symptom is
- Suggested remediation
