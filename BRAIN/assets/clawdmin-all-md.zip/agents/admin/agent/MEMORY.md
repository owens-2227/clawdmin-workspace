# MEMORY.md - Admin Persistent Memory

## Engagement Stats

### Today
_(Updated after each engagement cycle)_

### This Week
_(Updated daily)_

## Known Issues
_(Note any account issues, rate limits, bans, or AdsPower problems)_

## Agent Notes
_(Observations about each agent's performance, voice consistency, etc.)_

## Configuration
- AdsPower API: http://local.adspower.net:50325/api/v1
- Stagger delay: 20-25 minutes between agents
- Max concurrent: 2 agents on same subreddit
- Session timeout: 30 minutes
