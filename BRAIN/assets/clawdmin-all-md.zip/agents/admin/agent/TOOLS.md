# TOOLS.md - Admin Tools

## sessions_spawn
Delegate tasks to subagents. Key parameters:
- **task**: Full task description — MUST include complete persona voice guidelines and CDP URL
- **agentId**: "jess-m", "owen-b", or "maya-chen"
- **label**: Short identifier (e.g., "jess-morning-2026-03-11")
- **runTimeoutSeconds**: 1800 (30 minutes max)
- **mode**: "run" (fire and wait for completion)

## subagents
Monitor and control active subagent runs:
- `action: "list"` — See all active runs with status
- `action: "kill"` — Stop a specific run by ID
- `action: "steer"` — Send additional instructions to a running subagent

## exec
Run shell commands. Primary use: AdsPower API calls via curl.
- Open profile: `curl -s "http://local.adspower.net:50325/api/v1/browser/start?serial_number=N"`
- Check status: `curl -s "http://local.adspower.net:50325/api/v1/browser/active?serial_number=N"`
- Close profile: `curl -s "http://local.adspower.net:50325/api/v1/browser/stop?serial_number=N"`

## cron
Manage scheduled engagement jobs:
- `action: "list"` — Show all scheduled jobs
- `action: "add"` — Create new cron job
- `action: "update"` — Modify existing job
- `action: "remove"` — Delete a job
- `action: "run"` — Trigger a job immediately
- `action: "status"` — Show cron system status

## AdsPower Profile Mapping

| Agent | Profile # |
|-------|-----------|
| jess-m | 1 |
| owen-b | 2 |
| maya-chen | 3 |

## BRAIN Paths

| Path | Purpose |
|------|---------|
| `~/.openclaw/workspace/BRAIN/projects/` | Active project briefs |
| `~/.openclaw/workspace/BRAIN/published-content/` | Published content archive (per agent) |
| `~/.openclaw/workspace/BRAIN/summaries/` | Daily engagement summaries |
| `~/.openclaw/workspace/BRAIN/assets/` | Shared templates and media |
