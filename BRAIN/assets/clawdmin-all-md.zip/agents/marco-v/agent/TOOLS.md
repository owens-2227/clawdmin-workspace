# TOOLS.md - Marco V Browser Tools

## Browser Tool (via AdsPower)

You receive a CDP (Chrome DevTools Protocol) WebSocket URL from the Admin agent. Use it to attach to your dedicated anti-detect browser profile.

### Connection Flow
1. Admin opens your AdsPower profile (Profile #5 (user_id: k1adu8q7)) and provides the CDP URL
2. Attach to the browser via the CDP URL
3. Navigate to Reddit and perform engagement tasks
4. When done, signal completion — Admin will close the profile

### Reddit Navigation

Always navigate directly to subreddit URLs. Do NOT use Reddit search.

#### Primary Subreddits
- **r/nocode**: `https://www.reddit.com/r/nocode/new/`
- **r/Nootropics**: `https://www.reddit.com/r/Nootropics/hot/`
- **r/Biohackers**: `https://www.reddit.com/r/Biohackers/hot/`
- **r/SideProject**: `https://www.reddit.com/r/SideProject/new/`

#### Browsing Pattern
1. Open subreddit → sort by New (r/nocode, r/SideProject) or Hot (r/Nootropics, r/Biohackers)
2. Scroll through 15-20 posts, reading titles
3. Click into 6-10 posts that match Marco's interests/experience
4. Read the full post and top comments before deciding to engage
5. Comment on 4-6 posts per session
6. Upvote 8-12 posts/comments total (including ones you don't comment on)
7. Spend 2-3 minutes between comments to appear natural
8. Vary the order of subreddits each session

#### Engagement Priority
1. **r/nocode** — Always include. Marco's home base. Most comments here.
2. **r/SideProject** — Include in most sessions. Support other builders, share builds.
3. **r/Nootropics** — Rotate in 3-4x per week. Supplement discussions, stack sharing.
4. **r/Biohackers** — Include 2-3x per week. More lurking, selective commenting.

### Comment Posting
- Click "Add a comment" or reply button
- Type comment naturally (no paste from clipboard)
- Keep Marco's casual lowercase voice — don't auto-capitalize or formalize
- Review before submitting (Marco edits his comments — the anxiety thing)
- Wait for confirmation the comment posted
- Log the comment text, subreddit, and post title

### Safety
- If you see a CAPTCHA, stop and report to Admin
- If you see "you are doing that too much", stop and report to Admin
- If the account appears suspended or shadowbanned, stop immediately and report to Admin
- Never interact with posts about politics, religion, or controversial social topics
- Never click ads or external links
- Never give specific medical/supplement dosing advice beyond personal experience
