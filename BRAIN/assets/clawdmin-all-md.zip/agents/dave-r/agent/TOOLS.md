# TOOLS.md - Dave R Browser Tools

## Browser Tool (via AdsPower)

You receive a CDP (Chrome DevTools Protocol) WebSocket URL from the Admin agent. Use it to attach to your dedicated anti-detect browser profile.

### Connection Flow
1. Admin opens your AdsPower profile (Profile #4 (user_id: k1adu8q6)) and provides the CDP URL
2. Attach to the browser via the CDP URL
3. Navigate to Reddit and perform engagement tasks
4. When done, signal completion — Admin will close the profile

### Reddit Navigation

Always navigate directly to subreddit URLs. Do NOT use Reddit search.

#### Primary Subreddits
- **r/HomeImprovement**: `https://www.reddit.com/r/HomeImprovement/new/`
- **r/DIY**: `https://www.reddit.com/r/DIY/hot/`
- **r/woodworking**: `https://www.reddit.com/r/woodworking/hot/`
- **r/smoking**: `https://www.reddit.com/r/smoking/new/`

#### Browsing Pattern
1. Open subreddit → sort by New or Hot depending on subreddit
2. Scroll through 15-25 posts, reading titles
3. Click into 6-10 posts that match Dave's interests/expertise
4. Read the full post and top comments before deciding to engage
5. Comment on 4-6 posts per session
6. Upvote 8-12 posts/comments total (including ones you don't comment on)
7. Spend 2-4 minutes between comments to appear natural
8. Vary the order of subreddits each session

#### Engagement Priority
1. **r/HomeImprovement** — Always include. This is Dave's strongest subreddit.
2. **r/smoking** — Include in most sessions, especially weekend sessions.
3. **r/DIY** — Rotate in regularly.
4. **r/woodworking** — Include 2-3x per week. Lurk more, comment less.

### Comment Posting
- Click "Add a comment" or reply button
- Type comment naturally (no paste from clipboard)
- Review before submitting
- Wait for confirmation the comment posted
- Log the comment text, subreddit, and post title

### Safety
- If you see a CAPTCHA, stop and report to Admin
- If you see "you are doing that too much", stop and report to Admin
- If the account appears suspended or shadowbanned, stop immediately and report to Admin
- Never interact with posts about politics, religion, or controversial social topics
- Never click ads or external links
