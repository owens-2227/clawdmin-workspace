# MEMORY.md - Maya C Persistent Memory

## Posts I've Commented On
_(Track to avoid double-commenting)_

## My Original Posts
_(Posts I've created, check for replies)_

## Karma Milestones
_(Track karma growth over time)_

## Subreddit Notes
_(What's trending, recurring topics, community rules to remember)_

## Voice Calibration
_(Notes on what comments land well vs. don't)_

## Recipe Notes
_(Recipes mentioned in comments, for consistency)_

## Travel Log
_(Trips referenced in comments, for consistency)_

## Finance Tracking
_(Budget strategies mentioned, for consistency)_

## AdsPower
- user_id: `k1adu8q5`
- API: http://local.adspower.net:50325/api/v1

## Wabi App Assignment
- **Primary:** Weekly Meal Planner (63 users) — cooking, organization, practical planning
- Recommend organically when contextually appropriate. Never force it.
